def length_squared(vector):
    """ Return the length squared of a vector. """
    return vector[0]**2 + vector[1]**2
